package com.example.homeworkapp1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import static com.example.homeworkapp1.Constants.*;

public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_activity);

        final EditText nameTextView     = findViewById(R.id.name);
        final EditText surNameTextView  = findViewById(R.id.surname);
        final EditText ageTextView      = findViewById(R.id.age);
        final EditText genderTextView   = findViewById(R.id.gender);
        final Button   submitBtn        = findViewById(R.id.submit_btn);

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String nameStr    = nameTextView.getText().toString();
                final String surNameStr = surNameTextView.getText().toString();
                final String ageStr     = ageTextView.getText().toString();
                final String genderStr  = genderTextView .getText().toString();

                if (nameStr.isEmpty() || surNameStr.isEmpty() || ageStr.isEmpty() || genderStr.isEmpty()) {
                    final Intent intent = new Intent(FirstActivity.this,ThirdActivity.class);
                    startActivity(intent);
                    return;
                }
                final Intent intent = new Intent(FirstActivity.this, SecondActivity.class);
                intent.putExtra(NAME_KEY, nameStr);
                intent.putExtra(SURNAME_KEY, surNameStr);
                intent.putExtra(AGE_KEY, ageStr);
                intent.putExtra(GENDER_KEY, genderStr);
                startActivity(intent);
            }
        });
    }

}
