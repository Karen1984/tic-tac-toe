package com.example.homeworkapp1;

public final class Constants {
    public static final String NAME_KEY    = "name";
    public static final String SURNAME_KEY = "surname";
    public static final String AGE_KEY     = "age";
    public static final String GENDER_KEY  = "gender";
}
