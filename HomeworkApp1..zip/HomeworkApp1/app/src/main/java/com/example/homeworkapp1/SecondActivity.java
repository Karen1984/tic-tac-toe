package com.example.homeworkapp1;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import static com.example.homeworkapp1.Constants.*;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);

        final String name   = getIntent().getStringExtra(NAME_KEY);
        final String surName  = getIntent().getStringExtra(SURNAME_KEY);
        final String age    = getIntent().getStringExtra(AGE_KEY);
        final String gender = getIntent().getStringExtra(GENDER_KEY);

        final TextView textView = findViewById(R.id.second_text_view);

        textView.setText("Name is "+name+"\n\n"+"Surname is "+surName+"\n\n"+"Age is "+age+"\n\n"+"Gender is "+gender);








    }
}
